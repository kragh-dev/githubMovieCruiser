﻿using Com.Cognizant.Moviecuriser.Model;
using System;

namespace Com.Cognizant.Moviecuriser.Dao
{
    public class CartDaoCollectionTest
    {
        //creating only single object to store data....so we are passing object only in method
        /// <summary>
        /// TestAddCartItem method is used to movies to cart.it takes userid and movieitem id .
        /// based on movieid it takes data and adds to cart
        /// </summary>
        /// <param name="cartDao"></param>

        public void TestAddCartItem(CartDaoCollection cartDao)
        {
            Console.WriteLine("Enter UserId:");
            long userId = long.Parse(Console.ReadLine());
            Console.WriteLine("Enter Movie Item Id:");
            long movieItemId = long.Parse(Console.ReadLine());
            cartDao.AddCartItem(userId, movieItemId);
        }
        /// <summary>
        /// TestGetAllCartItem method is used to get all movies which are added in cart.it takes userid..
        /// particular Userid is having some cart details that should be displayed
        /// if particular userid is not present then it should show an error or exception
        /// </summary>
        /// <param name="cartDao"></param>
        public void TestGetAllCartItems(CartDaoCollection cartDao)
        {
            //ICartDao cd = new CartDaoCollection();
            MovieCart cartItems;
            Console.WriteLine("Enter User ID");
            long userId = long.Parse(Console.ReadLine());
            try
            {
                cartItems = cartDao.GetAllCartItems(userId);
                foreach (MovieItem movieitem in cartItems.MovieItemList)
                {
                    Console.WriteLine(movieitem);
                }

            }
            catch (CartEmptyException e)
            {
                Console.WriteLine(e);
            }
        }
        /// <summary>
        /// TestRemoveCartItem method is used to remove movies from cart.it takes userid and movieitemid
        /// It deletes movie in that userid cart
        /// if particular userid is not present then it should show an error or exception
        /// </summary>
        /// <param name="cartDao"></param>
        public void TestRemoveCartItems(CartDaoCollection cartDao)
        {

            Console.WriteLine("Enter UserId:");
            long userId = long.Parse(Console.ReadLine());
            Console.WriteLine("Enter MovieItemId");
            long movieItemId = long.Parse(Console.ReadLine());
            cartDao.RemoveCartItem(userId, movieItemId);
            MovieCart cartMovieItems;
            try
            {
                cartMovieItems = cartDao.GetAllCartItems(userId);
                foreach (MovieItem movieitem in cartMovieItems.MovieItemList)
                {
                    Console.WriteLine(movieitem);
                }

            }
            catch (CartEmptyException ce)
            {
                Console.WriteLine(ce);
            }

        }
        //this method is created to invoke all methods in the CartDaoCollectionTest and this method is invoked in MainClassPeogram project(Console Application)
        public void CartTest(CartDaoCollectionTest cartDao)
        {

            CartDaoCollection cd = new CartDaoCollection();
            //while is uesd to iterate loop for unlimited times
            while (true)
            {
                Console.WriteLine("Enter Method number which is to be executed");
                Console.WriteLine("1. TestAddCartItem ");
                Console.WriteLine("2. TestGetAllCartItems ");
                Console.WriteLine("3. TestRemoveCartItems ");
                int number = Convert.ToInt32(Console.ReadLine());
                if (number == 1)
                {
                    TestAddCartItem(cd);
                }
                else if (number == 2)
                {
                    TestGetAllCartItems(cd);
                }
                else if (number == 3)
                {
                    TestRemoveCartItems(cd);
                }
            }

        }
    }
}
