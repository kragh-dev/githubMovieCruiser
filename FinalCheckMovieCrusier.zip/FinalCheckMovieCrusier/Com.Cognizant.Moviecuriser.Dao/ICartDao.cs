﻿using Com.Cognizant.Moviecuriser.Model;
using System;
using System.Collections.Generic;
using System.Web;

namespace Com.Cognizant.Moviecuriser.Dao
{
    public interface ICartDao
    {
        //Abstracts Methods
        void AddCartItem(long userId, long movieItemId);
        MovieCart GetAllCartItems(long userId);
        void RemoveCartItem(long userId, long productId);
    }
    //Abstract methods are implementing ...............
    //CartDaoCollection class implements ICartDao (interface)
    public class CartDaoCollection : ICartDao
    {
        public int count=0;
        //creating an private dictonary having (key ,value) pairs of type long and MovieCart
        private Dictionary<long, MovieCart> Dictonary1 = new Dictionary<long, MovieCart>();
        public CartDaoCollection()
        {
            //if CartDaoCollection is empty ...then we need to create or to add new items
            if (HttpContext.Current.Session["cart"] == null)
            {
                Dictonary1 = new Dictionary<long, MovieCart>();
                HttpContext.Current.Session["cart"] = Dictonary1;

            }
            Dictonary1 = (Dictionary<long, MovieCart>)HttpContext.Current.Session["cart"];
        }
        private Dictionary<long, MovieCart> d = new Dictionary<long, MovieCart>();
        //AddCartItem is used to add movie in cart if that movieitemid is in movieitem class
        public void AddCartItem(long userId, long movieItemId)
        {
            MovieItemDaoCollection movieItemDao = new MovieItemDaoCollection();
            MovieItem movieitem = movieItemDao.GetMovieItem(movieItemId);
            if (Dictonary1.ContainsKey(userId))
            {
                Dictonary1[userId].MovieItemList.Add(movieitem);
                Dictonary1[userId].Total += movieitem.BoxOffice;
            }
            else
            {
                Dictonary1.Add(userId, new MovieCart(new List<MovieItem>() { movieitem }));
            }
            HttpContext.Current.Session["cart"] = Dictonary1;
            //foreach (KeyValuePair<long, MovieCart> item in Dictonary1)
            //{
            //    foreach (MovieItem movieItem in item.Value.MovieItemList)
            //    {
            //        Console.WriteLine(movieItem.ID + " " + movieItem.Name + " " + movieItem.BoxOffice + " " + movieItem.Active + " " + movieItem.Date + " " + movieItem.Genre + " " + movieItem.HasTeaser);
            //    }
            //}
        }
        //Getting all cartitems 
        public MovieCart GetAllCartItems(long userId)
        {
            if (Dictonary1.ContainsKey(userId))
            {
                return Dictonary1[userId];
                
            }
            else
            {

                throw new CartEmptyException("cart is empty");
            }
        }

        //removes cartitems from cart
        public void RemoveCartItem(long userId, long productId)
        {
            ////var item = Dictonary1[userId].MenuItemList[Convert.ToInt32(productId)];
            ////Dictonary1[userId].Total -= item.Price;
            ////Dictonary1[userId].MenuItemList.Remove(item);
            //MovieCart cartItems = GetAllCartItems(userId);
            //var item = cartItems.MovieItemList.FindIndex(p => p.ID == productId);
            //Dictonary1[userId].MovieItemList.Remove(cartItems.MovieItemList[item]);
            var cartItemsForUser = GetAllCartItems(userId);
            var item = cartItemsForUser.MovieItemList.FindIndex(p => p.ID == productId);
            this.Dictonary1[userId].MovieItemList.Remove(cartItemsForUser.MovieItemList[item]);
            MovieItemDaoCollection movieItemDao = new MovieItemDaoCollection();
            MovieItem movieitem = movieItemDao.GetMovieItem(productId);
            Dictonary1[userId].Total = Dictonary1[userId].Total - movieitem.BoxOffice;
            Dictonary1[userId] = cartItemsForUser;

            if (Dictonary1[userId].MovieItemList.Count == 0)
            {
                Dictonary1.Remove(userId);
            }
            HttpContext.Current.Session["cart"] = Dictonary1;
        }
    }


    public class MenuCart
    {
    }
}
