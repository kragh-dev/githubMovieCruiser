﻿using Com.Cognizant.Moviecuriser.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Com.Cognizant.Moviecuriser.Dao
{
    //Interface with abstract methods
     public interface IMovieItemDao
    {
        List<MovieItem> GetMovieItemListAdmin();
        List<MovieItem> GetMovieItemListCustomer();
        void ModifyMovieItem(MovieItem movieItem);
        MovieItem GetMovieItem(long movieItemId);
    }
    //MovieItemDaoCollection implementing IMovieItemDao 
    public class MovieItemDaoCollection : IMovieItemDao
    {
        private List<MovieItem> movieitemlist = new List<MovieItem>();
        //Constructor
        public MovieItemDaoCollection()
        {
            //if movieitemlist is empty then we are adding items to movieitem
            if (HttpContext.Current.Session["movieitems"] == null)
            {
                movieitemlist = new List<MovieItem>()
                {
                    new MovieItem(1, "Avatar", 99.00f, true, DateTime.ParseExact("26/04/2019","dd/MM/yyyy", null) , "Science Fiction", true),
                    new MovieItem(2, "The Avengers", 129.00f, true, DateTime.ParseExact("24/05/2019","dd/MM/yyyy", null) , "Superhero", true),
                    new MovieItem(3, "Titanic", 149.00f, true, DateTime.ParseExact("03/08/2019","dd/MM/yyyy", null), "Romance", true),
                    new MovieItem(4, "Jurassic World", 57.00f, true, DateTime.ParseExact("17/07/2019","dd/MM/yyyy", null) , "Science Fiction", true),
                    new MovieItem(5, "Avengers: End Game", 32.00f, true, DateTime.ParseExact("26/04/2019","dd/MM/yyyy", null) , "Superhero", true)
                    };
                HttpContext.Current.Session["movieitems"] = movieitemlist;
                //mi.add(2, "Burger", 129.00f, true, Convert.ToDateTime("23/12/2017"), "Main Course", true);

            }
            movieitemlist = (List<MovieItem>)HttpContext.Current.Session["movieitems"];
        }
        //getting movieitem based on movieitemid
        public MovieItem GetMovieItem(long movieItemId)
        {
            return movieitemlist.FirstOrDefault(m => m.ID == movieItemId);
        }
       //gets whole list 
        public List<MovieItem> GetMovieItemListAdmin()
        {
            return movieitemlist;
        }
        //Getting only movieitems status having true
        public List<MovieItem> GetMovieItemListCustomer()
        {
            List<MovieItem> movieitem1 = new List<MovieItem>();
            foreach (MovieItem movieItem in movieitemlist)
            {
                if (movieItem.Date < DateTime.Now && movieItem.Active == true)
                {
                    movieitem1.Add(movieItem);
                }
            }
            return movieitem1;
        }
        //used to modify movie item based on particular id and getting of index that id
        public void ModifyMovieItem(MovieItem movieItem)
        {
            foreach (var item in movieitemlist)
            {
                if (item.ID == movieItem.ID)
                {
                    item.Name = movieItem.Name;
                    item.BoxOffice = movieItem.BoxOffice;
                    item.Date = movieItem.Date;
                    item.Genre = movieItem.Genre;
                    item.Active = movieItem.Active;
                    item.HasTeaser = movieItem.HasTeaser;
                }
            }
            HttpContext.Current.Session["movieitems"] = movieitemlist;
        }
    }
}

