﻿using System;
using System.Runtime.Serialization;

namespace Com.Cognizant.Moviecuriser.Dao
{
    public class CartEmptyException : Exception
    {
        string output;
        public CartEmptyException(string message)
        {
            output = message;
            Console.WriteLine(message);
        }
        public override string ToString()
        {
            return output;
        }
    }
}