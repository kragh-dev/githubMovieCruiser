﻿using Com.Cognizant.Moviecuriser.Model;
using System;
using System.Collections.Generic;

namespace Com.Cognizant.Moviecuriser.Dao
{
    public class MovieItemDaoCollectionTest
    {
        //All movieitems will visible to the Admin
        public void TestGetMovieItemListAdmin()
        {
            IMovieItemDao movieItemDao = new MovieItemDaoCollection();
            List<MovieItem> movieitem = movieItemDao.GetMovieItemListAdmin();
            Console.WriteLine("Get Menu Item List Admin");
            foreach (MovieItem movieItem in movieitem)
            {
                Console.WriteLine(movieItem);
            }
        }
        //Only status true will be visible to the Customer
        public void TestMovieItemListCustomer()
        {
            IMovieItemDao movieItemDao = new MovieItemDaoCollection();
            List<MovieItem> movieitem1 = movieItemDao.GetMovieItemListCustomer();
            Console.WriteLine("Get Menu Item List Customer");
            foreach (MovieItem movieItem in movieitem1)
            {
                Console.WriteLine(movieItem);
            }

        }
        //modifying movie
        public void TestModifyMovieItem()
        {
            IMovieItemDao movieItemDao = new MovieItemDaoCollection();
            List<MovieItem> movieitem = movieItemDao.GetMovieItemListAdmin();
            Console.WriteLine("Enter ID");
            long id = long.Parse(Console.ReadLine());
            Console.WriteLine("Enter Name");
            string name = Console.ReadLine();
            Console.WriteLine("Enter BoxOffice");
            float boxoffice = float.Parse(Console.ReadLine());
            Console.WriteLine("Enter Status (yes/No)");
            string active = Console.ReadLine();
            //Boolean active = Boolean.Parse(Console.ReadLine());
            //Console.WriteLine("Enter Date Of Launch");
            //DateTime DateOfLaunch = Convert.ToDateTime(Console.ReadLine());
            //Console.WriteLine("Enter Category");
            //string category = Console.ReadLine();
            //Console.WriteLine("Enter Whether there is free Delivery or not (Yes/No)");
            //Boolean freeDelivery = Boolean.Parse(Console.ReadLine());

            Boolean ActiveStatus;
            //foreach(MenuItem menuitem1 in menuitem)
            //{
            if (active.Equals("yes", StringComparison.InvariantCultureIgnoreCase))
            {
                ActiveStatus = true;
            }
            else
            {
                ActiveStatus = false;
            }
            //Boolean active = Boolean.Parse(Console.ReadLine());
            Console.WriteLine("Enter Date Of Launch");
            DateTime DateOfLaunch = Convert.ToDateTime(Console.ReadLine());
            Console.WriteLine("Enter Category");
            string genre = Console.ReadLine();
            Console.WriteLine("Enter Whether there is free Delivery or not (Yes/No)");
            string hasteaser = Console.ReadLine();
            Boolean hasteaserStatus;
            if (hasteaser.Equals("yes", StringComparison.InvariantCultureIgnoreCase))
            {
                hasteaserStatus = true;
            }
            else
            {
                hasteaserStatus = false;
            }
            movieItemDao.ModifyMovieItem(new MovieItem(id, name, boxoffice, ActiveStatus, DateOfLaunch, hasteaser, hasteaserStatus));

            foreach (MovieItem movieitem1 in movieitem)
            {
                Console.WriteLine(movieitem1);
            }
            //}
        }
        public void TestGetMovieItem()
        {
            Console.WriteLine("Enter id");
            long id1 = long.Parse(Console.ReadLine());
            IMovieItemDao movieItemDao = new MovieItemDaoCollection();
            Console.WriteLine(movieItemDao.GetMovieItem(id1));
        }
        //All methods od MovieItemDaoCollectionTest is are invoked in this method
        public void MovieItemTest()
        {
            MovieItemDaoCollectionTest md = new MovieItemDaoCollectionTest();
            while (true)
            {
                Console.WriteLine("Enter Method number which is to be executed");
                Console.WriteLine("1. TestGetMovieItemListAdmin ");
                Console.WriteLine("2. TestMovieItemListCustomer ");
                Console.WriteLine("3. TestModifyMovieItem ");
                Console.WriteLine("4. TestGetMovieItem ");
                int number = Convert.ToInt32(Console.ReadLine());
                if (number == 1)
                {
                    md.TestGetMovieItemListAdmin();
                }
                else if (number == 2)
                {
                    md.TestMovieItemListCustomer();
                }
                else if (number == 3)
                {
                    md.TestModifyMovieItem();
                }
                else if (number == 4)
                {
                    md.TestGetMovieItem();
                }
            }
        }
    }
}
