﻿using System;

namespace Com.Cognizant.Moviecuriser.Model
{
    public class MovieItem
    {
        //datetypes
        private long id;
        private string title;
        private float boxoffice;
        private Boolean active;
        private DateTime DateOfLaunch;
        private string genre;
        private Boolean hasteaser;
        //properties for variables
        public long ID
        {
            get
            {
                return id;
            }
            set { id = value; }
        }
        public string Name
        {
            get
            {
                return title;
            }
            set { title = value; }
        }
        public float BoxOffice
        {
            get
            {
                return boxoffice;
            }
            set { boxoffice = value; }
        }
        public Boolean Active
        {
            get
            {
                return active;
            }
            set { active = value; }
        }
        public DateTime Date
        {
            get
            {
                return DateOfLaunch;
            }
            set { DateOfLaunch = value; }
        }
        public string Genre
        {
            get
            {
                return genre;
            }
            set { genre = value; }
        }
        public Boolean HasTeaser
        {
            get
            {
                return hasteaser;
            }
            set { hasteaser = value; }
        }
        //Default constructor 
        public MovieItem()
        {

        }
        //overloading constructor
        public MovieItem(long id, string title, float boxoffice, Boolean active, DateTime DateOfLaunch, string genre, Boolean hasteaser)
        {
            //pointing to current object
            this.id = id;
            this.title = title;
            this.boxoffice = boxoffice;
            this.active = active;
            this.DateOfLaunch = DateOfLaunch;
            this.genre = genre;
            this.hasteaser = hasteaser;
        }
        public override string ToString()
        {
            return "id=" + id + "name=" + title + "boxoffice " + boxoffice + "active " + active + "DateOfLaunch " + DateOfLaunch + "genre " + genre + "hasteaser " + hasteaser;
        }


    }
}
