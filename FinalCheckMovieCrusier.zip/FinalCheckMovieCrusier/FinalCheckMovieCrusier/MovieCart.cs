﻿using System.Collections.Generic;

namespace Com.Cognizant.Moviecuriser.Model
{
    public class MovieCart
    {
        //creating list with type movieitem
        private List<MovieItem> movieItemList = new List<MovieItem>();
        private double total;

        private List<MovieItem> list;

        //properties
        public List<MovieItem> MovieItemList
        {
            get
            {
                return movieItemList;
            }
            set
            {
                movieItemList = value;
            }
        }
        public double Total
        {
            get
            {
                return total;
            }
            set
            {
                total = movieItemList.Count;
            }
        }
        //Default Constructor
        public MovieCart()
        {

        }
        //Overloading Default Constructor
        public MovieCart(List<MovieItem> movieItemList, double total)
        {
            //this keyword is used to point the current object
            this.movieItemList = movieItemList;
            this.total = total;
        }

        public MovieCart(List<MovieItem> list)
        {
            this.movieItemList = list;
        }

        public override string ToString()
        {
            return "movieItemList: " + movieItemList + "total: " + total;
        }
    }
}

