﻿using System;
using System.Collections.Generic;
using System.Linq;
using Com.Cognizant.Moviecuriser.Dao;
using Com.Cognizant.Moviecuriser.Model;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MovieCrusier
{
    public partial class AddToCart : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                var movieItemID = Convert.ToInt64(Request.QueryString["movieItemId"]);
                long userID = 1;

                ICartDao cartDao = new CartDaoCollection();
                cartDao.AddCartItem(userID, movieItemID);

                IMovieItemDao menuItemDaoCollection = new MovieItemDaoCollection();

                gvMovieItems.DataSource = menuItemDaoCollection.GetMovieItemListCustomer();
                gvMovieItems.DataBind();
            }
        }
    }
}