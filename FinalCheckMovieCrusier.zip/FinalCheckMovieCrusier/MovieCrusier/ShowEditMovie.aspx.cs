﻿using System;
using System.Collections.Generic;
using System.Linq;
using Com.Cognizant.Moviecuriser.Dao;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MovieCrusier
{
    public partial class ShowEditMovie : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                IMovieItemDao movieItemDaoCollection = new MovieItemDaoCollection();

                var movieItemID = Convert.ToInt64(Request.QueryString["movieItemId"]);

                var movieItem = movieItemDaoCollection.GetMovieItem(movieItemID);

                txtName.Text = movieItem.Name;
                txtBoxOffice.Text = movieItem.BoxOffice.ToString();
                txtDate.Text = movieItem.Date.ToString("yyyy-MM-dd");
                ddlCategory.SelectedValue = movieItem.Genre;
                rblActive.SelectedValue = (movieItem.Active) ? "Yes" : "No";
                chkFree.Checked = movieItem.HasTeaser;
            }
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            var movieItemID = Convert.ToInt64(Request.QueryString["movieItemId"]);
            var movieItem = new Com.Cognizant.Moviecuriser.Model.MovieItem()
            {
                Name = txtName.Text,
                BoxOffice = Convert.ToInt64(txtBoxOffice.Text),
                Date = Convert.ToDateTime(txtDate.Text),
                Genre = ddlCategory.SelectedValue,
                Active = rblActive.SelectedValue == "Yes",
                HasTeaser = chkFree.Checked,
                ID = movieItemID
            };
            IMovieItemDao movieItemDaoCollection = new MovieItemDaoCollection();
            movieItemDaoCollection.ModifyMovieItem(movieItem);
            Response.Redirect("EditMovieStatus.aspx");
            txtName.Text = "";
            txtBoxOffice.Text = "";
            txtDate.Text = "";
            ddlCategory.SelectedValue = "";
            rblActive.SelectedValue = "";
            chkFree.Checked = false;
        }
    }
    
}