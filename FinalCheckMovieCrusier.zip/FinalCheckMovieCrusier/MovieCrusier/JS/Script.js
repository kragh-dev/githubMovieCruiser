﻿function myFunction() {
    var numbers = /^[0-9]+$/;
    var Name = document.getElementById('body_txtName').value;
    var Price = document.getElementById('body_txtPrice').value;
    if (Name == "") {
        alert("Please Enter Name");
        return false;
    }
    if (isNaN(Price) || Price == "") {
        alert("please enter price or enter numeric values");
        return false;
    }
    return true;
}
