﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Com.Cognizant.Moviecuriser.Dao;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MovieCrusier
{
    public partial class ShowMovieListCustomer : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            IMovieItemDao MovieItemDao = new MovieItemDaoCollection();
            gvCartItems.DataSource = MovieItemDao.GetMovieItemListCustomer();
            gvCartItems.DataBind();
        }
    }
}