﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Com.Cognizant.Moviecuriser.Dao;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MovieCrusier
{
    public partial class RemoveCart : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            var movieItemID = Convert.ToInt64(Request.QueryString["movieItemId"]);
            long userID = 1;

            ICartDao cartDao = new CartDaoCollection();
            cartDao.RemoveCartItem(userID, movieItemID);

            try
            {
                var itemsInCart = cartDao.GetAllCartItems(userID);
                gvMovieItems.DataSource = itemsInCart.MovieItemList;
                gvMovieItems.DataBind();
                lblTotal.Text = itemsInCart.Total.ToString();
            }
            catch (CartEmptyException)
            {
                Response.Redirect("CartEmpty.aspx");
            }
        }
    }
}