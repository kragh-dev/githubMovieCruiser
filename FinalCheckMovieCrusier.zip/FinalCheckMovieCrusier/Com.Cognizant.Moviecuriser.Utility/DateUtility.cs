﻿using System;

namespace Com.Cognizant.Moviecuriser.Utility
{
    public class DateUtility
    {
        //String to datetime type conversion
        public DateTime ConvertToDate(string inputDate)
        {
            return Convert.ToDateTime(inputDate);
        }
    }
}
